export interface Lead {
  id: number;
  business_name: string;
  category: string;
  phone?: string;
  email?: string;
  website?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  rating?: number;
  review_count?: number;
  latitude?: number;
  longitude?: number;
  google_place_id?: string;
  has_website?: number;
  has_social_media?: number;
  score?: number;
  status?: 'new' | 'contacted' | 'follow_up' | 'proposal' | 'won' | 'lost';
  notes?: string;
  tags?: string;
  created_at?: number;
  updated_at?: number;
}

export interface Category {
  id: number;
  name: string;
  icon: string;
  color: string;
  is_active: number;
}

export interface Activity {
  id: number;
  lead_id: number;
  type: string;
  description: string;
  created_at: number;
}

export interface SearchParams {
  city: string;
  category: string;
  state?: string;
  limit?: number;
}
