import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import Papa from 'papaparse';
import { Lead } from '@/utils/types';

export const exportLeadsToCSV = async (leads: Lead[]): Promise<boolean> => {
  try {
    const csvData = leads.map(lead => ({
      'Business Name': lead.business_name,
      'Category': lead.category,
      'Phone': lead.phone || '',
      'Email': lead.email || '',
      'Website': lead.website || '',
      'Address': lead.address || '',
      'City': lead.city || '',
      'State': lead.state || '',
      'Rating': lead.rating || '',
      'Reviews': lead.review_count || '',
      'Score': lead.score || '',
      'Status': lead.status || 'new',
      'Notes': lead.notes || '',
      'Tags': lead.tags || '',
    }));

    const csv = Papa.unparse(csvData);
    const fileName = `data-ai-leads-${Date.now()}.csv`;
    const filePath = `${FileSystem.documentDirectory}${fileName}`;

    await FileSystem.writeAsStringAsync(filePath, csv);

    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(filePath, {
        mimeType: 'text/csv',
        dialogTitle: 'Export Leads to CSV',
      });
      return true;
    }
    return false;
  } catch (error) {
    console.error('Export error:', error);
    return false;
  }
};

export const exportLeadsToJSON = async (leads: Lead[]): Promise<boolean> => {
  try {
    const fileName = `data-ai-leads-${Date.now()}.json`;
    const filePath = `${FileSystem.documentDirectory}${fileName}`;

    await FileSystem.writeAsStringAsync(filePath, JSON.stringify(leads, null, 2));

    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(filePath, {
        mimeType: 'application/json',
        dialogTitle: 'Export Leads to JSON',
      });
      return true;
    }
    return false;
  } catch (error) {
    console.error('Export error:', error);
    return false;
  }
};
