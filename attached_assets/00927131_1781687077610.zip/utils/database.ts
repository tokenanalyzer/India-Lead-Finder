import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

export const getDB = async (): Promise<SQLite.SQLiteDatabase> => {
  if (!db) {
    db = await SQLite.openDatabaseAsync('dataai.db');
    await initTables();
  }
  return db;
};

const initTables = async () => {
  const database = await getDB();

  await database.execAsync(`
    CREATE TABLE IF NOT EXISTS leads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_name TEXT NOT NULL,
      category TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      website TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      country TEXT DEFAULT 'India',
      rating REAL,
      review_count INTEGER,
      latitude REAL,
      longitude REAL,
      google_place_id TEXT,
      has_website INTEGER DEFAULT 0,
      has_social_media INTEGER DEFAULT 0,
      score INTEGER DEFAULT 0,
      status TEXT DEFAULT 'new',
      notes TEXT,
      tags TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now')),
      updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      icon TEXT,
      color TEXT DEFAULT '#2DD4BF',
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lead_id INTEGER,
      type TEXT NOT NULL,
      description TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now')),
      FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_leads_category ON leads(category);
    CREATE INDEX IF NOT EXISTS idx_leads_city ON leads(city);
    CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
    CREATE INDEX IF NOT EXISTS idx_leads_score ON leads(score);
  `);

  const defaultCategories = [
    ['Clinic', 'Stethoscope', '#2DD4BF'],
    ['Hospital', 'Building', '#FB7185'],
    ['Dentist', 'Smile', '#A78BFA'],
    ['Coaching Class', 'BookOpen', '#FBBF24'],
    ['School', 'GraduationCap', '#34D399'],
    ['Gym', 'Dumbbell', '#2DD4BF'],
    ['Salon', 'Scissors', '#FB7185'],
    ['Restaurant', 'UtensilsCrossed', '#A78BFA'],
    ['Cafe', 'Coffee', '#FBBF24'],
    ['Garment Shop', 'Shirt', '#34D399'],
    ['Textile Shop', 'Layers', '#2DD4BF'],
    ['Saree Store', 'Ribbon', '#FB7185'],
    ['Manufacturer', 'Factory', '#A78BFA'],
    ['Exporter', 'Ship', '#FBBF24'],
    ['Distributor', 'Truck', '#34D399'],
    ['Builder', 'Hammer', '#2DD4BF'],
    ['Real Estate', 'Home', '#FB7185'],
    ['Lawyer', 'Scale', '#A78BFA'],
    ['CA', 'Calculator', '#FBBF24'],
    ['Kirana Store', 'Store', '#34D399'],
    ['Hardware Store', 'Wrench', '#2DD4BF'],
    ['Mobile Shop', 'Smartphone', '#FB7185'],
    ['Electronics', 'Tv', '#A78BFA'],
    ['Furniture', 'Sofa', '#FBBF24'],
    ['Shopify Brand', 'ShoppingBag', '#34D399'],
    ['D2C Brand', 'Package', '#2DD4BF'],
  ];

  for (const cat of defaultCategories) {
    await database.runAsync(
      'INSERT OR IGNORE INTO categories (name, icon, color) VALUES (?, ?, ?)',
      cat
    );
  }
};

export const resetDatabase = async () => {
  const database = await getDB();
  await database.execAsync('DROP TABLE IF EXISTS leads;');
  await database.execAsync('DROP TABLE IF EXISTS categories;');
  await database.execAsync('DROP TABLE IF EXISTS activities;');
  db = null;
};

export default getDB;
