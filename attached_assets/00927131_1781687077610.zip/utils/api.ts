import { SearchParams, Lead } from '@/utils/types';

const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY || '';

export const searchBusinesses = async (params: SearchParams): Promise<Lead[]> => {
  try {
    const { city, category, state = 'Maharashtra', limit = 20 } = params;
    const query = `${category} in ${city}, ${state}, India`;

    const textSearchUrl = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${GOOGLE_API_KEY}&region=in`;

    const searchRes = await fetch(textSearchUrl);
    const searchData = await searchRes.json();

    if (searchData.status !== 'OK') {
      console.warn('Google API status:', searchData.status);
      return [];
    }

    const results = searchData.results.slice(0, limit);
    const leads: Lead[] = [];

    for (let i = 0; i < results.length; i++) {
      const place = results[i];
      if (i > 0) await new Promise(r => setTimeout(r, 200));

      const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=name,formatted_phone_number,website,formatted_address,geometry,rating,user_ratings_total,types&key=${GOOGLE_API_KEY}`;

      const detailsRes = await fetch(detailsUrl);
      const detailsData = await detailsRes.json();

      if (detailsData.status === 'OK') {
        const detail = detailsData.result;
        const address = detail.formatted_address || place.formatted_address || '';

        leads.push({
          id: 0,
          business_name: detail.name || place.name,
          category: category,
          phone: detail.formatted_phone_number || '',
          website: detail.website || '',
          address: address,
          city: city,
          state: state,
          country: 'India',
          rating: detail.rating || place.rating || 0,
          review_count: detail.user_ratings_total || place.user_ratings_total || 0,
          latitude: detail.geometry?.location?.lat || place.geometry?.location?.lat,
          longitude: detail.geometry?.location?.lng || place.geometry?.location?.lng,
          google_place_id: place.place_id,
          has_website: detail.website ? 1 : 0,
          has_social_media: 0,
          score: calculateScore(detail.website, detail.rating),
          status: 'new',
          created_at: Date.now(),
        });
      }
    }

    return leads;
  } catch (error) {
    console.error('Search error:', error);
    return [];
  }
};

const calculateScore = (website?: string, rating?: number): number => {
  let score = 50;
  if (!website) score += 30;
  if (!rating || rating < 3.0) score += 10;
  if (rating && rating > 4.0) score -= 10;
  return Math.min(100, Math.max(0, score));
};

export const checkWebsite = async (url: string): Promise<{ exists: boolean; mobileFriendly: boolean; hasHttps: boolean }> => {
  try {
    const res = await fetch(url, { method: 'HEAD' });
    return {
      exists: res.status < 400,
      mobileFriendly: true,
      hasHttps: url.startsWith('https'),
    };
  } catch {
    return { exists: false, mobileFriendly: false, hasHttps: false };
  }
};
