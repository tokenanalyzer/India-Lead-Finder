import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { COLORS, SHADOWS } from '@/constants/theme';
import { Search, Database, ArrowRight } from 'lucide-react-native';

export default function WelcomeScreen() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#E9D5FF', '#FED7AA', '#FAFAF9']}
        style={styles.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      <View style={styles.content}>
        <View style={styles.logoSection}>
          <View style={styles.logoContainer}>
            <Search size={40} color={COLORS.lavender} />
            <View style={styles.sparkle}>
              <View style={styles.sparkleDot} />
            </View>
          </View>
          <Text style={styles.appName}>Data AI</Text>
          <Text style={styles.tagline}>Business Leads, Smartly Found</Text>
        </View>

        <BlurView intensity={25} style={styles.glassCard} tint="light">
          <View style={styles.cardContent}>
            <View style={styles.featureRow}>
              <View style={[styles.iconCircle, { backgroundColor: COLORS.teal + '20' }]}>
                <Search size={20} color={COLORS.teal} />
              </View>
              <View style={styles.featureText}>
                <Text style={styles.featureTitle}>Find Leads</Text>
                <Text style={styles.featureDesc}>Search businesses by city & category</Text>
              </View>
            </View>

            <View style={styles.featureRow}>
              <View style={[styles.iconCircle, { backgroundColor: COLORS.coral + '20' }]}>
                <Database size={20} color={COLORS.coral} />
              </View>
              <View style={styles.featureText}>
                <Text style={styles.featureTitle}>Store Offline</Text>
                <Text style={styles.featureDesc}>Save unlimited leads on your device</Text>
              </View>
            </View>
          </View>
        </BlurView>

        <Pressable 
          onPress={() => router.push('/(tabs)')}
          style={({ pressed }) => [
            styles.button,
            { transform: [{ scale: pressed ? 0.96 : 1 }] }
          ]}
        >
          <LinearGradient
            colors={[COLORS.teal, COLORS.tealLight]}
            style={styles.buttonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.buttonText}>Get Started</Text>
            <ArrowRight size={20} color="#fff" />
          </LinearGradient>
        </Pressable>

        <Text style={styles.footer}>v1.0.0 • Offline First • Free Forever</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  gradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    ...SHADOWS.medium,
  },
  sparkle: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  sparkleDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.warning,
  },
  appName: {
    fontSize: 36,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  tagline: {
    fontSize: 15,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  glassCard: {
    width: '100%',
    borderRadius: 28,
    overflow: 'hidden',
    marginBottom: 32,
    backgroundColor: 'rgba(255,255,255,0.5)',
  },
  cardContent: {
    padding: 24,
    gap: 20,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  iconCircle: {
    width: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureText: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 2,
  },
  featureDesc: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  button: {
    width: '100%',
    borderRadius: 20,
    overflow: 'hidden',
    ...SHADOWS.glow,
  },
  buttonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '600',
  },
  footer: {
    marginTop: 24,
    fontSize: 12,
    color: COLORS.textMuted,
  },
});
