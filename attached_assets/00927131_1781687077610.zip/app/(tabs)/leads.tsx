import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import { getDB } from '@/utils/database';
import { useStore } from '@/hooks/useStore';
import { exportLeadsToCSV, exportLeadsToJSON } from '@/utils/export';
import { COLORS, STATUSES } from '@/constants/theme';
import GlassCard from '@/components/GlassCard';
import LeadCard from '@/components/LeadCard';
import SearchBar from '@/components/SearchBar';
import { FileSpreadsheet, FileJson, Filter, ChevronDown } from 'lucide-react-native';

export default function LeadsScreen() {
  const router = useRouter();
  const { leads, setLeads, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory } = useStore();
  const [refreshing, setRefreshing] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const loadLeads = async () => {
    try {
      const db = await getDB();
      let query = 'SELECT * FROM leads WHERE 1=1';
      const params: any[] = [];

      if (searchQuery) {
        query += ' AND (business_name LIKE ? OR phone LIKE ? OR city LIKE ?)';
        params.push(`%${searchQuery}%`, `%${searchQuery}%`, `%${searchQuery}%`);
      }

      if (selectedCategory && selectedCategory !== 'All') {
        query += ' AND category = ?';
        params.push(selectedCategory);
      }

      if (filterStatus) {
        query += ' AND status = ?';
        params.push(filterStatus);
      }

      query += ' ORDER BY score DESC, created_at DESC';

      const results = await db.getAllAsync(query, params);
      setLeads(results as any);
    } catch (e) {
      console.error('Load leads error:', e);
    }
  };

  useEffect(() => {
    loadLeads();
  }, [searchQuery, selectedCategory, filterStatus]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadLeads();
    setRefreshing(false);
  };

  const handleExportCSV = async () => {
    await exportLeadsToCSV(leads);
  };

  const handleExportJSON = async () => {
    await exportLeadsToJSON(leads);
  };

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.teal} />}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>My Leads</Text>
            <Text style={styles.subtitle}>{leads.length} total leads</Text>
          </View>
          <View style={styles.exportButtons}>
            <Pressable onPress={handleExportCSV} style={styles.exportBtn}>
              <FileSpreadsheet size={18} color={COLORS.teal} />
            </Pressable>
            <Pressable onPress={handleExportJSON} style={styles.exportBtn}>
              <FileJson size={18} color={COLORS.coral} />
            </Pressable>
          </View>
        </View>

        <SearchBar 
          value={searchQuery} 
          onChangeText={setSearchQuery} 
          placeholder="Search by name, phone, city..."
        />

        <Pressable onPress={() => setShowFilters(!showFilters)} style={styles.filterToggle}>
          <Filter size={16} color={COLORS.textSecondary} />
          <Text style={styles.filterToggleText}>Filters</Text>
          <ChevronDown size={16} color={COLORS.textSecondary} style={{ transform: [{ rotate: showFilters ? '180deg' : '0deg' }] }} />
        </Pressable>

        {showFilters && (
          <GlassCard style={styles.filterCard}>
            <Text style={styles.filterTitle}>Status</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.statusScroll}>
              <Pressable 
                onPress={() => setFilterStatus(null)}
                style={[styles.statusChip, !filterStatus && styles.statusChipActive]}
              >
                <Text style={[styles.statusText, !filterStatus && styles.statusTextActive]}>All</Text>
              </Pressable>
              {STATUSES.map(s => (
                <Pressable
                  key={s.value}
                  onPress={() => setFilterStatus(filterStatus === s.value ? null : s.value)}
                  style={[styles.statusChip, filterStatus === s.value && { backgroundColor: s.color + '20' }]}
                >
                  <Text style={[styles.statusText, filterStatus === s.value && { color: s.color, fontWeight: '600' }]}>
                    {s.label}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </GlassCard>
        )}

        {leads.length === 0 ? (
          <GlassCard style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>No leads found</Text>
            <Text style={styles.emptyDesc}>Search for leads or import from CSV</Text>
          </GlassCard>
        ) : (
          leads.map((lead, i) => (
            <LeadCard key={lead.id} lead={lead} index={i} />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 100,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  exportButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  exportBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)',
  },
  filterToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  filterToggleText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  filterCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  filterTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 10,
  },
  statusScroll: {
    flexDirection: 'row',
  },
  statusChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.04)',
    marginRight: 8,
  },
  statusChipActive: {
    backgroundColor: COLORS.teal + '20',
  },
  statusText: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  statusTextActive: {
    color: COLORS.teal,
    fontWeight: '600',
  },
  emptyCard: {
    marginHorizontal: 16,
    padding: 40,
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 6,
  },
  emptyDesc: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
});
