import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { getDB } from '@/utils/database';
import { useStore } from '@/hooks/useStore';
import { searchBusinesses } from '@/utils/api';
import { COLORS, CITIES } from '@/constants/theme';
import GlassCard from '@/components/GlassCard';
import LeadCard from '@/components/LeadCard';
import { MapPin, Filter, Save, Check } from 'lucide-react-native';

const CATEGORIES = [
  'Clinic', 'Hospital', 'Dentist', 'Coaching Class', 'School',
  'Gym', 'Salon', 'Restaurant', 'Cafe', 'Garment Shop',
  'Textile Shop', 'Saree Store', 'Manufacturer', 'Exporter',
  'Distributor', 'Builder', 'Real Estate', 'Lawyer', 'CA',
  'Kirana Store', 'Hardware Store', 'Mobile Shop', 'Electronics',
  'Furniture', 'Shopify Brand', 'D2C Brand',
];

export default function SearchScreen() {
  const { selectedCity, setSelectedCity, selectedCategory, setSelectedCategory, setToast } = useStore();
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);

  const handleSearch = async () => {
    if (!selectedCity || selectedCategory === 'All') {
      Alert.alert('Select City & Category', 'Please choose both a city and business category to search.');
      return;
    }

    setIsLoading(true);
    try {
      const results = await searchBusinesses({
        city: selectedCity,
        category: selectedCategory,
        limit: 20,
      });
      setSearchResults(results);
      setSavedIds(new Set());
    } catch (error) {
      console.error('Search error:', error);
      Alert.alert('Error', 'Failed to fetch leads. Check your API key.');
    } finally {
      setIsLoading(false);
    }
  };

  const saveLead = async (lead: any) => {
    try {
      const db = await getDB();
      const result = await db.runAsync(
        `INSERT INTO leads (business_name, category, phone, email, website, address, city, state, country, rating, review_count, latitude, longitude, google_place_id, has_website, score, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          lead.business_name, lead.category, lead.phone || '', lead.email || '',
          lead.website || '', lead.address || '', lead.city || '', lead.state || 'Maharashtra',
          lead.country || 'India', lead.rating || 0, lead.review_count || 0,
          lead.latitude || 0, lead.longitude || 0, lead.google_place_id || '',
          lead.has_website || 0, lead.score || 50, 'new', Date.now()
        ]
      );

      setSavedIds(prev => new Set(prev).add(lead.google_place_id));
      setToast({ message: 'Lead saved!', type: 'success' });
    } catch (error) {
      console.error('Save error:', error);
      setToast({ message: 'Failed to save', type: 'error' });
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#FAFAF9', '#F5F5F4']} style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Find Leads</Text>
            <Text style={styles.subtitle}>Search businesses from Google Maps</Text>
          </View>

          <GlassCard style={styles.filterCard}>
            <Pressable onPress={() => { setShowCityPicker(!showCityPicker); setShowCategoryPicker(false); }} style={styles.filterRow}>
              <MapPin size={18} color={COLORS.teal} />
              <Text style={styles.filterLabel}>City:</Text>
              <Text style={styles.filterValue}>{selectedCity}</Text>
              <Filter size={16} color={COLORS.textMuted} />
            </Pressable>

            {showCityPicker && (
              <View style={styles.pickerContainer}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.pickerScroll}>
                  {CITIES.map(city => (
                    <Pressable
                      key={city}
                      onPress={() => { setSelectedCity(city); setShowCityPicker(false); }}
                      style={[styles.pickerItem, selectedCity === city && styles.pickerItemActive]}
                    >
                      <Text style={[styles.pickerText, selectedCity === city && styles.pickerTextActive]}>{city}</Text>
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            )}

            <Pressable onPress={() => { setShowCategoryPicker(!showCategoryPicker); setShowCityPicker(false); }} style={styles.filterRow}>
              <Filter size={18} color={COLORS.coral} />
              <Text style={styles.filterLabel}>Category:</Text>
              <Text style={styles.filterValue}>{selectedCategory}</Text>
              <Filter size={16} color={COLORS.textMuted} />
            </Pressable>

            {showCategoryPicker && (
              <View style={styles.pickerContainer}>
                <ScrollView style={styles.categoryScroll}>
                  {CATEGORIES.map(cat => (
                    <Pressable
                      key={cat}
                      onPress={() => { setSelectedCategory(cat); setShowCategoryPicker(false); }}
                      style={[styles.categoryItem, selectedCategory === cat && styles.categoryItemActive]}
                    >
                      <Text style={[styles.categoryText, selectedCategory === cat && styles.categoryTextActive]}>{cat}</Text>
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            )}
          </GlassCard>

          <Pressable onPress={handleSearch} style={styles.searchButton} disabled={isLoading}>
            <LinearGradient colors={[COLORS.teal, COLORS.tealLight]} style={styles.searchGradient}>
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Text style={styles.searchButtonText}>Search Google Maps</Text>
                  <MapPin size={18} color="#fff" />
                </>
              )}
            </LinearGradient>
          </Pressable>

          {searchResults.length > 0 && (
            <View style={styles.resultsSection}>
              <Text style={styles.resultsTitle}>{searchResults.length} leads found</Text>
              {searchResults.map((lead, index) => (
                <View key={lead.google_place_id || index} style={styles.resultWrapper}>
                  <LeadCard lead={lead} index={index} />
                  <Pressable 
                    onPress={() => saveLead(lead)}
                    style={[styles.saveButton, savedIds.has(lead.google_place_id) && styles.savedButton]}
                  >
                    {savedIds.has(lead.google_place_id) ? (
                      <Check size={16} color={COLORS.success} />
                    ) : (
                      <Save size={16} color={COLORS.teal} />
                    )}
                    <Text style={[styles.saveText, savedIds.has(lead.google_place_id) && styles.savedText]}>
                      {savedIds.has(lead.google_place_id) ? 'Saved' : 'Save'}
                    </Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 100,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  filterCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 10,
  },
  filterLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
    width: 70,
  },
  filterValue: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  pickerContainer: {
    marginTop: 8,
    marginBottom: 8,
  },
  pickerScroll: {
    flexDirection: 'row',
  },
  pickerItem: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.04)',
    marginRight: 8,
    marginBottom: 8,
  },
  pickerItemActive: {
    backgroundColor: COLORS.teal + '20',
  },
  pickerText: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  pickerTextActive: {
    color: COLORS.teal,
    fontWeight: '600',
  },
  categoryScroll: {
    maxHeight: 200,
  },
  categoryItem: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.03)',
    marginBottom: 6,
  },
  categoryItemActive: {
    backgroundColor: COLORS.coral + '20',
  },
  categoryText: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  categoryTextActive: {
    color: COLORS.coral,
    fontWeight: '600',
  },
  searchButton: {
    marginHorizontal: 16,
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
  },
  searchGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 10,
  },
  searchButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  resultsSection: {
    paddingHorizontal: 4,
  },
  resultsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginHorizontal: 16,
    marginBottom: 12,
  },
  resultWrapper: {
    position: 'relative',
  },
  saveButton: {
    position: 'absolute',
    top: 20,
    right: 32,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.9)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    zIndex: 10,
  },
  savedButton: {
    backgroundColor: COLORS.success + '15',
  },
  saveText: {
    fontSize: 12,
    color: COLORS.teal,
    fontWeight: '600',
  },
  savedText: {
    color: COLORS.success,
  },
});
