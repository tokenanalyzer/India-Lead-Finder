import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { getDB } from '@/utils/database';
import { COLORS } from '@/constants/theme';
import GlassCard from '@/components/GlassCard';
import { TrendingUp, Users, Target, Award } from 'lucide-react-native';

export default function AnalyticsScreen() {
  const [stats, setStats] = useState({
    total: 0,
    byCategory: [] as { category: string; count: number }[],
    byStatus: [] as { status: string; count: number }[],
    highScore: 0,
    noWebsite: 0,
  });

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const db = await getDB();
      const total = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM leads');

      const byCategory = await db.getAllAsync<{ category: string; count: number }>(
        'SELECT category, COUNT(*) as count FROM leads GROUP BY category ORDER BY count DESC LIMIT 8'
      );

      const byStatus = await db.getAllAsync<{ status: string; count: number }>(
        'SELECT status, COUNT(*) as count FROM leads GROUP BY status'
      );

      const highScore = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM leads WHERE score >= 70');
      const noWebsite = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM leads WHERE has_website = 0');

      setStats({
        total: total?.count || 0,
        byCategory: byCategory as any,
        byStatus: byStatus as any,
        highScore: highScore?.count || 0,
        noWebsite: noWebsite?.count || 0,
      });
    } catch (e) {
      console.error('Analytics error:', e);
    }
  };

  const statusColors: Record<string, string> = {
    new: '#93C5FD',
    contacted: '#FBBF24',
    follow_up: '#A78BFA',
    proposal: '#FB7185',
    won: '#34D399',
    lost: '#9CA3AF',
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Analytics</Text>
          <Text style={styles.subtitle}>Your lead performance</Text>
        </View>

        <View style={styles.summaryGrid}>
          <GlassCard style={styles.summaryCard}>
            <Users size={24} color={COLORS.teal} />
            <Text style={styles.summaryValue}>{stats.total}</Text>
            <Text style={styles.summaryLabel}>Total Leads</Text>
          </GlassCard>
          <GlassCard style={styles.summaryCard}>
            <Target size={24} color={COLORS.coral} />
            <Text style={styles.summaryValue}>{stats.highScore}</Text>
            <Text style={styles.summaryLabel}>High Priority</Text>
          </GlassCard>
          <GlassCard style={styles.summaryCard}>
            <TrendingUp size={24} color={COLORS.lavender} />
            <Text style={styles.summaryValue}>{stats.noWebsite}</Text>
            <Text style={styles.summaryLabel}>No Website</Text>
          </GlassCard>
          <GlassCard style={styles.summaryCard}>
            <Award size={24} color={COLORS.success} />
            <Text style={styles.summaryValue}>
              {stats.total > 0 ? Math.round((stats.byStatus.find(s => s.status === 'won')?.count || 0) / stats.total * 100) : 0}%
            </Text>
            <Text style={styles.summaryLabel}>Win Rate</Text>
          </GlassCard>
        </View>

        {stats.byCategory.length > 0 && (
          <GlassCard style={styles.chartCard}>
            <Text style={styles.chartTitle}>Top Categories</Text>
            <View style={styles.categoryList}>
              {stats.byCategory.map((c, i) => (
                <View key={i} style={styles.categoryBar}>
                  <View style={styles.categoryLabelRow}>
                    <Text style={styles.categoryLabel}>{c.category}</Text>
                    <Text style={styles.categoryCount}>{c.count}</Text>
                  </View>
                  <View style={styles.progressBg}>
                    <View style={[styles.progressFill, {
                      width: `${stats.total > 0 ? (c.count / stats.total) * 100 : 0}%`,
                      backgroundColor: [COLORS.teal, COLORS.coral, COLORS.lavender, COLORS.success, COLORS.warning, COLORS.info][i % 6],
                    }]} />
                  </View>
                </View>
              ))}
            </View>
          </GlassCard>
        )}

        {stats.byStatus.length > 0 && (
          <GlassCard style={styles.chartCard}>
            <Text style={styles.chartTitle}>Status Distribution</Text>
            <View style={styles.statusList}>
              {stats.byStatus.map((s, i) => (
                <View key={i} style={styles.statusBar}>
                  <View style={styles.statusLabelRow}>
                    <View style={[styles.statusDot, { backgroundColor: statusColors[s.status] || COLORS.textMuted }]} />
                    <Text style={styles.statusLabel}>{s.status}</Text>
                    <Text style={styles.statusCount}>{s.count}</Text>
                  </View>
                  <View style={styles.progressBg}>
                    <View style={[styles.progressFill, {
                      width: `${stats.total > 0 ? (s.count / stats.total) * 100 : 0}%`,
                      backgroundColor: statusColors[s.status] || COLORS.textMuted,
                    }]} />
                  </View>
                </View>
              ))}
            </View>
          </GlassCard>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 100,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 8,
    marginBottom: 20,
  },
  summaryCard: {
    width: '47%',
    padding: 16,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  chartCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  categoryList: {
    gap: 12,
  },
  categoryBar: {
    gap: 6,
  },
  categoryLabelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  categoryCount: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  statusList: {
    gap: 12,
  },
  statusBar: {
    gap: 6,
  },
  statusLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  statusLabel: {
    flex: 1,
    fontSize: 13,
    color: COLORS.textSecondary,
    textTransform: 'capitalize',
  },
  statusCount: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  progressBg: {
    height: 6,
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 3,
  },
  progressFill: {
    height: 6,
    borderRadius: 3,
  },
});
