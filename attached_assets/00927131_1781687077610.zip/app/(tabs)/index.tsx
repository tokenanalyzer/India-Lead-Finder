import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { getDB } from '@/utils/database';
import { useStore } from '@/hooks/useStore';
import { COLORS, SHADOWS } from '@/constants/theme';
import GlassCard from '@/components/GlassCard';
import LeadCard from '@/components/LeadCard';
import { Users, Phone, CheckCircle, TrendingUp, Plus, ArrowRight, Search, List } from 'lucide-react-native';

export default function DashboardScreen() {
  const router = useRouter();
  const { leads, setLeads } = useStore();
  const [stats, setStats] = useState({ total: 0, contacted: 0, won: 0, conversion: 0 });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const db = await getDB();
      const total = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM leads');
      const contacted = await db.getFirstAsync<{ count: number }>("SELECT COUNT(*) as count FROM leads WHERE status != 'new'");
      const won = await db.getFirstAsync<{ count: number }>("SELECT COUNT(*) as count FROM leads WHERE status = 'won'");

      const totalCount = total?.count || 0;
      const contactedCount = contacted?.count || 0;
      const wonCount = won?.count || 0;

      setStats({
        total: totalCount,
        contacted: contactedCount,
        won: wonCount,
        conversion: totalCount > 0 ? Math.round((wonCount / totalCount) * 100) : 0,
      });

      const recent = await db.getAllAsync('SELECT * FROM leads ORDER BY created_at DESC LIMIT 5');
      setLeads(recent as any);
    } catch (e) {
      console.error('Stats error:', e);
    }
  };

  const statCards = [
    { label: 'Total Leads', value: stats.total, icon: Users, color: COLORS.teal, bg: COLORS.teal + '15' },
    { label: 'Contacted', value: stats.contacted, icon: Phone, color: COLORS.coral, bg: COLORS.coral + '15' },
    { label: 'Won', value: stats.won, icon: CheckCircle, color: COLORS.success, bg: COLORS.success + '15' },
    { label: 'Conversion', value: `${stats.conversion}%`, icon: TrendingUp, color: COLORS.lavender, bg: COLORS.lavender + '15' },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#E9D5FF10', '#FAFAF9']} style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <View>
              <Text style={styles.greeting}>Good Day!</Text>
              <Text style={styles.subtitle}>Your lead dashboard</Text>
            </View>
            <Pressable 
              onPress={() => router.push('/(tabs)/search')}
              style={styles.addButton}
            >
              <Plus size={22} color="#fff" />
            </Pressable>
          </View>

          <View style={styles.statsGrid}>
            {statCards.map((stat, i) => (
              <GlassCard key={i} style={styles.statCard}>
                <View style={[styles.iconBg, { backgroundColor: stat.bg }]}>
                  <stat.icon size={20} color={stat.color} />
                </View>
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </GlassCard>
            ))}
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
          </View>
          <View style={styles.actionsRow}>
            <Pressable onPress={() => router.push('/(tabs)/search')} style={styles.actionButton}>
              <LinearGradient colors={[COLORS.teal, COLORS.tealLight]} style={styles.actionGradient}>
                <Search size={20} color="#fff" />
                <Text style={styles.actionText}>Find Leads</Text>
              </LinearGradient>
            </Pressable>
            <Pressable onPress={() => router.push('/(tabs)/leads')} style={styles.actionButton}>
              <LinearGradient colors={[COLORS.coral, COLORS.coralLight]} style={styles.actionGradient}>
                <List size={20} color="#fff" />
                <Text style={styles.actionText}>My Leads</Text>
              </LinearGradient>
            </Pressable>
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Leads</Text>
            <Pressable onPress={() => router.push('/(tabs)/leads')}>
              <Text style={styles.seeAll}>See All <ArrowRight size={14} /></Text>
            </Pressable>
          </View>

          {leads.length === 0 ? (
            <GlassCard style={styles.emptyCard}>
              <Text style={styles.emptyText}>No leads yet. Start searching!</Text>
            </GlassCard>
          ) : (
            leads.slice(0, 3).map((lead, i) => (
              <LeadCard key={lead.id} lead={lead} index={i} />
            ))
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 100,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: COLORS.teal,
    justifyContent: 'center',
    alignItems: 'center',
    ...SHADOWS.glow,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 8,
    marginBottom: 24,
  },
  statCard: {
    width: '47%',
    padding: 16,
  },
  iconBg: {
    width: 40,
    height: 40,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 12,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  seeAll: {
    fontSize: 13,
    color: COLORS.teal,
    fontWeight: '500',
  },
  actionsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    ...SHADOWS.soft,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  actionText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyCard: {
    marginHorizontal: 16,
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
});
