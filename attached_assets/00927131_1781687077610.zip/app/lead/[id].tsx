import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, Alert, Linking } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { getDB } from '@/utils/database';
import { Lead } from '@/utils/types';
import { COLORS, STATUSES } from '@/constants/theme';
import GlassCard from '@/components/GlassCard';
import { ArrowLeft, Phone, Globe, MapPin, Star, Edit3, Check, Trash2, ExternalLink } from 'lucide-react-native';

export default function LeadDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [lead, setLead] = useState<Lead | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    loadLead();
  }, [id]);

  const loadLead = async () => {
    try {
      const db = await getDB();
      const result = await db.getFirstAsync('SELECT * FROM leads WHERE id = ?', [id]);
      if (result) {
        setLead(result as Lead);
        setNotes((result as Lead).notes || '');
        setTags((result as Lead).tags || '');
      }
    } catch (e) {
      console.error('Load lead error:', e);
    }
  };

  const updateStatus = async (status: string) => {
    try {
      const db = await getDB();
      await db.runAsync('UPDATE leads SET status = ?, updated_at = ? WHERE id = ?', [status, Date.now(), id]);
      setLead(prev => prev ? { ...prev, status: status as any } : null);
    } catch (e) {
      console.error('Update error:', e);
    }
  };

  const saveNotes = async () => {
    try {
      const db = await getDB();
      await db.runAsync('UPDATE leads SET notes = ?, tags = ?, updated_at = ? WHERE id = ?', [notes, tags, Date.now(), id]);
      setIsEditing(false);
      setLead(prev => prev ? { ...prev, notes, tags } : null);
    } catch (e) {
      console.error('Save notes error:', e);
    }
  };

  const deleteLead = async () => {
    Alert.alert(
      'Delete Lead',
      'Are you sure you want to delete this lead?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const db = await getDB();
              await db.runAsync('DELETE FROM leads WHERE id = ?', [id]);
              router.back();
            } catch (e) {
              console.error('Delete error:', e);
            }
          },
        },
      ]
    );
  };

  const openWebsite = async (url?: string) => {
    if (url) {
      const formatted = url.startsWith('http') ? url : `https://${url}`;
      await Linking.openURL(formatted);
    }
  };

  const callPhone = async (phone?: string) => {
    if (phone) {
      await Linking.openURL(`tel:${phone}`);
    }
  };

  if (!lead) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  const statusConfig = STATUSES.find(s => s.value === lead.status) || STATUSES[0];

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <ArrowLeft size={22} color={COLORS.textPrimary} />
          </Pressable>
          <View style={styles.headerActions}>
            <Pressable onPress={() => isEditing ? saveNotes() : setIsEditing(!isEditing)} style={styles.headerBtn}>
              {isEditing ? <Check size={20} color={COLORS.success} /> : <Edit3 size={20} color={COLORS.teal} />}
            </Pressable>
            <Pressable onPress={deleteLead} style={styles.headerBtn}>
              <Trash2 size={20} color={COLORS.coral} />
            </Pressable>
          </View>
        </View>

        <GlassCard style={styles.mainCard}>
          <Text style={styles.businessName}>{lead.business_name}</Text>
          <View style={styles.categoryRow}>
            <View style={[styles.categoryTag, { backgroundColor: statusConfig.color + '20' }]}>
              <Text style={[styles.categoryText, { color: statusConfig.color }]}>{lead.category}</Text>
            </View>
            <View style={[styles.scoreBadge, { backgroundColor: (lead.score || 50) >= 70 ? COLORS.coral + '20' : COLORS.teal + '20' }]}>
              <Text style={[styles.scoreText, { color: (lead.score || 50) >= 70 ? COLORS.coral : COLORS.teal }]}>
                Score: {lead.score}
              </Text>
            </View>
          </View>
        </GlassCard>

        <View style={styles.actionsRow}>
          {lead.phone && (
            <Pressable onPress={() => callPhone(lead.phone)} style={[styles.actionBtn, { backgroundColor: COLORS.teal + '15' }]}>
              <Phone size={22} color={COLORS.teal} />
              <Text style={[styles.actionText, { color: COLORS.teal }]}>Call</Text>
            </Pressable>
          )}
          {lead.website && (
            <Pressable onPress={() => openWebsite(lead.website)} style={[styles.actionBtn, { backgroundColor: COLORS.lavender + '15' }]}>
              <Globe size={22} color={COLORS.lavender} />
              <Text style={[styles.actionText, { color: COLORS.lavender }]}>Website</Text>
            </Pressable>
          )}
          <Pressable onPress={() => {}} style={[styles.actionBtn, { backgroundColor: COLORS.coral + '15' }]}>
            <ExternalLink size={22} color={COLORS.coral} />
            <Text style={[styles.actionText, { color: COLORS.coral }]}>Maps</Text>
          </Pressable>
        </View>

        <GlassCard style={styles.detailsCard}>
          <Text style={styles.sectionTitle}>Details</Text>

          {lead.phone && (
            <View style={styles.detailRow}>
              <Phone size={16} color={COLORS.teal} />
              <Text style={styles.detailLabel}>Phone</Text>
              <Text style={styles.detailValue}>{lead.phone}</Text>
            </View>
          )}
          {lead.email && (
            <View style={styles.detailRow}>
              <Globe size={16} color={COLORS.lavender} />
              <Text style={styles.detailLabel}>Email</Text>
              <Text style={styles.detailValue}>{lead.email}</Text>
            </View>
          )}
          {lead.address && (
            <View style={styles.detailRow}>
              <MapPin size={16} color={COLORS.coral} />
              <Text style={styles.detailLabel}>Address</Text>
              <Text style={styles.detailValue}>{lead.address}</Text>
            </View>
          )}
          <View style={styles.detailRow}>
            <Star size={16} color={COLORS.warning} />
            <Text style={styles.detailLabel}>Rating</Text>
            <Text style={styles.detailValue}>{lead.rating?.toFixed(1) || 'N/A'} ({lead.review_count || 0} reviews)</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.statusCard}>
          <Text style={styles.sectionTitle}>Status</Text>
          <View style={styles.statusGrid}>
            {STATUSES.map(s => (
              <Pressable
                key={s.value}
                onPress={() => updateStatus(s.value)}
                style={[styles.statusBtn, lead.status === s.value && { backgroundColor: s.color + '20', borderColor: s.color }]}
              >
                <View style={[styles.statusDot, { backgroundColor: s.color }]} />
                <Text style={[styles.statusBtnText, lead.status === s.value && { color: s.color, fontWeight: '600' }]}>
                  {s.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </GlassCard>

        <GlassCard style={styles.notesCard}>
          <Text style={styles.sectionTitle}>Notes</Text>
          {isEditing ? (
            <>
              <TextInput
                style={styles.notesInput}
                multiline
                numberOfLines={4}
                value={notes}
                onChangeText={setNotes}
                placeholder="Add notes about this lead..."
                placeholderTextColor={COLORS.textMuted}
              />
              <TextInput
                style={[styles.notesInput, { marginTop: 10 }]}
                value={tags}
                onChangeText={setTags}
                placeholder="Tags (comma separated)"
                placeholderTextColor={COLORS.textMuted}
              />
              <Pressable onPress={saveNotes} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>Save Notes</Text>
              </Pressable>
            </>
          ) : (
            <>
              <Text style={styles.notesText}>{lead.notes || 'No notes added'}</Text>
              {lead.tags && (
                <View style={styles.tagsRow}>
                  {lead.tags.split(',').map((tag, i) => (
                    <View key={i} style={styles.tagChip}>
                      <Text style={styles.tagText}>{tag.trim()}</Text>
                    </View>
                  ))}
                </View>
              )}
            </>
          )}
        </GlassCard>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 40,
  },
  loadingText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 100,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mainCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  businessName: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
  },
  categoryText: {
    fontSize: 13,
    fontWeight: '500',
  },
  scoreBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
  },
  scoreText: {
    fontSize: 13,
    fontWeight: '600',
  },
  actionsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 16,
  },
  actionBtn: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    borderRadius: 18,
    gap: 6,
  },
  actionText: {
    fontSize: 13,
    fontWeight: '600',
  },
  detailsCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 14,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.04)',
  },
  detailLabel: {
    width: 70,
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  detailValue: {
    flex: 1,
    fontSize: 14,
    color: COLORS.textPrimary,
    fontWeight: '500',
  },
  statusCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  statusGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  statusBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.03)',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusBtnText: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  notesCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  notesInput: {
    backgroundColor: 'rgba(0,0,0,0.03)',
    borderRadius: 14,
    padding: 14,
    fontSize: 14,
    color: COLORS.textPrimary,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  notesText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  tagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  tagChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: COLORS.tagBlue + '20',
  },
  tagText: {
    fontSize: 12,
    color: COLORS.tagBlue,
    fontWeight: '500',
  },
  saveBtn: {
    marginTop: 12,
    backgroundColor: COLORS.teal,
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  saveBtnText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});
