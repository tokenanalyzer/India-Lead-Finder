export const COLORS = {
  background: '#FAFAF9',
  backgroundWarm: '#F5F5F4',
  glassBg: 'rgba(255, 255, 255, 0.65)',
  glassBorder: 'rgba(255, 255, 255, 0.5)',
  teal: '#2DD4BF',
  tealLight: '#5EEAD4',
  coral: '#FB7185',
  coralLight: '#FDA4AF',
  lavender: '#A78BFA',
  lavenderLight: '#C4B5FD',
  success: '#34D399',
  warning: '#FBBF24',
  info: '#93C5FD',
  textPrimary: '#1F2937',
  textSecondary: '#6B7280',
  textMuted: '#9CA3AF',
  tagBlue: '#93C5FD',
  tagPink: '#F9A8D4',
  tagGreen: '#6EE7B7',
  tagPurple: '#D8B4FE',
  tagOrange: '#FDBA74',
};

export const SHADOWS = {
  soft: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 4,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 8,
  },
  glow: {
    shadowColor: '#2DD4BF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 0,
  },
};

export const CITIES = [
  'Thane', 'Mumbai', 'Pune', 'Nashik', 'Nagpur',
  'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Kolkata',
  'Ahmedabad', 'Surat', 'Jaipur', 'Lucknow', 'Kanpur',
  'Indore', 'Bhopal', 'Patna', 'Vadodara', 'Ludhiana',
];

export const STATUSES = [
  { value: 'new', label: 'New', color: '#93C5FD' },
  { value: 'contacted', label: 'Contacted', color: '#FBBF24' },
  { value: 'follow_up', label: 'Follow Up', color: '#A78BFA' },
  { value: 'proposal', label: 'Proposal', color: '#FB7185' },
  { value: 'won', label: 'Won', color: '#34D399' },
  { value: 'lost', label: 'Lost', color: '#9CA3AF' },
];
