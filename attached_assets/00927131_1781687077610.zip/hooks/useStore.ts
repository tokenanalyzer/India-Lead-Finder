import { create } from 'zustand';
import { Lead, Category } from '@/utils/types';

interface AppState {
  leads: Lead[];
  selectedLead: Lead | null;
  setLeads: (leads: Lead[]) => void;
  addLead: (lead: Lead) => void;
  updateLead: (id: number, updates: Partial<Lead>) => void;
  deleteLead: (id: number) => void;
  setSelectedLead: (lead: Lead | null) => void;
  categories: Category[];
  setCategories: (cats: Category[]) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  setToast: (toast: { message: string; type: 'success' | 'error' | 'info' } | null) => void;
}

export const useStore = create<AppState>((set) => ({
  leads: [],
  selectedLead: null,
  setLeads: (leads) => set({ leads }),
  addLead: (lead) => set((state) => ({ leads: [lead, ...state.leads] })),
  updateLead: (id, updates) => set((state) => ({
    leads: state.leads.map((l) => l.id === id ? { ...l, ...updates } : l),
  })),
  deleteLead: (id) => set((state) => ({
    leads: state.leads.filter((l) => l.id !== id),
  })),
  setSelectedLead: (lead) => set({ selectedLead: lead }),
  categories: [],
  setCategories: (categories) => set({ categories }),
  searchQuery: '',
  setSearchQuery: (searchQuery) => set({ searchQuery }),
  selectedCity: 'Thane',
  setSelectedCity: (selectedCity) => set({ selectedCity }),
  selectedCategory: 'All',
  setSelectedCategory: (selectedCategory) => set({ selectedCategory }),
  isLoading: false,
  setIsLoading: (isLoading) => set({ isLoading }),
  toast: null,
  setToast: (toast) => set({ toast }),
}));
