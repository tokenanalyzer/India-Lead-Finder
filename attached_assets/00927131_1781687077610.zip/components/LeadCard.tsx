import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Lead } from '@/utils/types';
import { COLORS } from '@/constants/theme';
import GlassCard from './GlassCard';
import { Phone, MapPin, Star, Globe, ChevronRight } from 'lucide-react-native';

interface LeadCardProps {
  lead: Lead;
  index: number;
}

export const LeadCard: React.FC<LeadCardProps> = ({ lead, index }) => {
  const router = useRouter();

  const getScoreColor = (score?: number) => {
    if (!score || score < 40) return COLORS.teal;
    if (score < 70) return COLORS.warning;
    return COLORS.coral;
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'new': return COLORS.tagBlue;
      case 'contacted': return COLORS.tagOrange;
      case 'follow_up': return COLORS.lavender;
      case 'proposal': return COLORS.coral;
      case 'won': return COLORS.success;
      case 'lost': return COLORS.textMuted;
      default: return COLORS.tagBlue;
    }
  };

  return (
    <Pressable 
      onPress={() => router.push(`/lead/${lead.id}`)}
      style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] })}
    >
      <GlassCard style={{ marginHorizontal: 16, marginBottom: 12 }}>
        <View style={styles.header}>
          <View style={styles.titleSection}>
            <Text style={styles.businessName} numberOfLines={1}>{lead.business_name}</Text>
            <View style={[styles.categoryTag, { backgroundColor: getStatusColor(lead.status) + '20' }]}>
              <Text style={[styles.categoryText, { color: getStatusColor(lead.status) }]}>
                {lead.category}
              </Text>
            </View>
          </View>
          <View style={[styles.scoreBadge, { backgroundColor: getScoreColor(lead.score) + '20' }]}>
            <Text style={[styles.scoreText, { color: getScoreColor(lead.score) }]}>
              {lead.score || 0}
            </Text>
          </View>
        </View>

        <View style={styles.details}>
          {lead.phone && (
            <View style={styles.detailRow}>
              <Phone size={14} color={COLORS.teal} />
              <Text style={styles.detailText}>{lead.phone}</Text>
            </View>
          )}
          {lead.address && (
            <View style={styles.detailRow}>
              <MapPin size={14} color={COLORS.coral} />
              <Text style={styles.detailText} numberOfLines={1}>{lead.address}</Text>
            </View>
          )}
          {lead.website && (
            <View style={styles.detailRow}>
              <Globe size={14} color={COLORS.lavender} />
              <Text style={[styles.detailText, { color: COLORS.lavender }]} numberOfLines={1}>{lead.website}</Text>
            </View>
          )}
        </View>

        <View style={styles.footer}>
          <View style={styles.ratingRow}>
            <Star size={14} color={COLORS.warning} fill={COLORS.warning} />
            <Text style={styles.ratingText}>{lead.rating?.toFixed(1) || '0.0'} ({lead.review_count || 0})</Text>
          </View>
          <ChevronRight size={18} color={COLORS.textMuted} />
        </View>
      </GlassCard>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  titleSection: {
    flex: 1,
    marginRight: 12,
  },
  businessName: {
    fontSize: 17,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 6,
  },
  categoryTag: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  categoryText: {
    fontSize: 11,
    fontWeight: '500',
  },
  scoreBadge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    minWidth: 40,
    alignItems: 'center',
  },
  scoreText: {
    fontSize: 13,
    fontWeight: '700',
  },
  details: {
    gap: 6,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
    paddingTop: 10,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
});

export default LeadCard;
