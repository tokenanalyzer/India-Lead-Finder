# Data AI - Lead Intelligence App

## Setup Instructions (Termux / Mobile)

1. Install dependencies:
```bash
npm install
```

2. Add your Google Maps API key:
```bash
cp .env.example .env
# Edit .env and add your GOOGLE_MAPS_API_KEY
```

3. Start the app:
```bash
npx expo start
```

## Features
- Search businesses via Google Maps API
- Offline SQLite storage
- CRM status tracking
- CSV/JSON export
- Analytics dashboard
- Glassmorphism UI

## Tech Stack
- Expo SDK 52
- React Native 0.76
- SQLite (offline)
- Zustand (state)
- Google Maps API
